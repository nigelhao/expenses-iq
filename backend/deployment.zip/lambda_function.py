import json
import uuid
import datetime
import boto3
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError
import requests
import math
import pytz
import os
from hashlib import sha256
from datetime import datetime, timedelta


def lambda_handler(event, context):
    print(event)
    if event["httpMethod"] == "OPTIONS":
        return {
            "statusCode": 200,
        }

    session_valid, session_data = verify_session(get_cookie(event, "SESSION_ID"))
    api = event["pathParameters"]["api"].split("/")[0]

    if api == "transactions":
        if not session_valid:
            return {
                "statusCode": 401,
                "body": json.dumps(session_data),
            }

        return route_transactions(event)

    elif api == "sign-up" and event["httpMethod"] == "POST":
        if session_valid:
            return {
                "statusCode": 403,
            }
        return {
            "statusCode": create_account(event),
            "headers": {
                "content-type": "application/json",
            },
        }

    elif api == "sign-in" and event["httpMethod"] == "POST":
        if session_valid:
            return {
                "statusCode": 403,
            }

        statusCode, session_id = verify_account(event)
        return {
            "statusCode": statusCode,
            "headers": {
                "content-type": "application/json",
                "set-cookie": f"SESSION_ID={session_id}; Secure; HttpOnly; SameSite=None;",
            },
            "body": json.dumps(session_valid),
        }
    elif (api == "sign-in" or api == "sign-up") and event["httpMethod"] == "GET":
        if session_valid:
            return {
                "statusCode": 403,
            }
        else:
            return {
                "statusCode": 200,
            }
    else:
        return {
            "statusCode": 404,
        }


def route_transactions(event=None):
    if event["httpMethod"] == "GET":
        result = get_transactions(event)
        return {
            "statusCode": result["status"],
            "headers": {
                "content-type": "application/json",
            },
            "body": json.dumps(result["body"]),
        }

    elif event["httpMethod"] == "POST":
        statusCode = insert_transaction(event)
        return {
            "statusCode": statusCode,
            "headers": {
                "content-type": "application/json",
            },
        }
    else:
        return {
            "statusCode": 404,
        }


def create_session(data=None, dynamodb=None):
    if not dynamodb:
        dynamodb = boto3.resource("dynamodb")

    # Calculate the current time plus 30 days for TTL (in seconds)
    ttl = (datetime.now() + timedelta(days=30)).timestamp()
    session_id = str(uuid.uuid4())
    try:
        table = dynamodb.Table("baas-db")
        table.put_item(
            Item={
                "PK": "SESSION",
                "SK": session_id,
                "email": data["email"],
                "name": data["name"],
                "ExpireAt": int(ttl),  # Add the TTL attribute
            }
        )

    except Exception as e:
        raise Exception("Something went wrong")

    return session_id


def verify_session(session_id, dynamodb=None):
    if session_id:
        if not dynamodb:
            dynamodb = boto3.resource("dynamodb")

        table = dynamodb.Table("baas-db")
        response = table.query(
            KeyConditionExpression=Key("PK").eq("SESSION") & Key("SK").eq(session_id),
        )

        if bool(response["Items"]):
            return True, response["Items"][0]
        else:
            return False, {}
    else:
        return False, {}


def create_account(event=None, dynamodb=None):
    data = json.loads(event["body"])

    if not dynamodb:
        dynamodb = boto3.resource("dynamodb")

    try:
        if not account_exist(event, dynamodb):
            table = dynamodb.Table("baas-db")
            table.put_item(
                Item={
                    "PK": "ACCOUNT",
                    "SK": data["email"],
                    "password": sha256(data["password"].encode()).hexdigest(),
                    "name": data["name"],
                }
            )

            status = 201
        else:
            status = 409
    except Exception as e:
        print(e)
        status = 500

    return status


def verify_account(event=None, dynamodb=None):
    data = json.loads(event["body"])

    if not dynamodb:
        dynamodb = boto3.resource("dynamodb")

    try:
        table = dynamodb.Table("baas-db")

        response = table.query(
            KeyConditionExpression=Key("PK").eq("ACCOUNT")
            & Key("SK").eq(data["email"]),
        )

        if (
            bool(response["Items"])
            and response["Items"][0]["password"]
            == sha256(data["password"].encode()).hexdigest()
        ):
            session_id = create_session(
                {
                    "email": response["Items"][0]["SK"],
                    "name": response["Items"][0]["name"],
                }
            )
            return 200, session_id
        else:
            return 401, ""

    except ClientError as e:
        return 500, ""


def account_exist(event=None, dynamodb=None):
    data = json.loads(event["body"])

    if not dynamodb:
        dynamodb = boto3.resource("dynamodb")

    try:
        table = dynamodb.Table("baas-db")

        response = table.query(
            KeyConditionExpression=Key("PK").eq("ACCOUNT")
            & Key("SK").eq(data["email"]),
        )

        return bool(response["Items"])

    except ClientError as e:
        raise Exception("Something went wrong")


def get_transactions(event=None, dynamodb=None):
    if not dynamodb:
        dynamodb = boto3.resource("dynamodb")

    transactions = []
    try:
        table = dynamodb.Table("baas-db")
        response = table.query(
            KeyConditionExpression=Key("PK").eq("TRANSACTION"),
        )

        transactions = response["Items"]
        status = 200

    except ClientError as e:
        print(e)
        status = 500

    return {"status": status, "body": {"data": transactions}}


def insert_transaction(event=None, dynamodb=None):
    data = json.loads(event["body"])

    if not dynamodb:
        dynamodb = boto3.resource("dynamodb")

    try:
        ai_responses = format_description_to_json(data["description"])

        table = dynamodb.Table("baas-db")

        for response in ai_responses:
            if math.isnan(response["amount"]):
                raise Exception("Amount not a number")

            converted_amount = convert_to_sgd(response["amount"], response["currency"])

            # Get the current datetime in Singapore time zone
            singapore_tz = pytz.timezone("Asia/Singapore")
            singapore_time = datetime.now(tz=singapore_tz).isoformat()

            table.put_item(
                Item={
                    "PK": "TRANSACTION",
                    "SK": str(uuid.uuid4()),
                    "date": singapore_time,
                    "simple_description": response["name"],
                    "original_description": data["description"],
                    "category": response["category"],
                    "sgd_amount": str(converted_amount),
                    "original_amount": str(response["amount"]),
                    "original_currency": str(response["currency"]),
                }
            )

        status = 201
    except Exception as e:
        print(e)
        status = 500

    return status


def format_description_to_json(description):
    # URL for OpenAI's completions endpoint
    url = "https://api.openai.com/v1/chat/completions"

    # The API key for authorization
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {os.environ.get('OPENAI_API_KEY')}",
    }

    # The data payload for the request, formatted as JSON
    payload = {
        "model": "gpt-3.5-turbo",
        "temperature": 0,
        "messages": [
            {
                "role": "system",
                "content": "You are a translator from a text description to JSON. If there are more than 1 transaction in the description, separate them. Output should only be an array JSON",
            },
            {
                "role": "user",
                "content": f"""
                    Given a description generate a name (no more than 5 words) by summarising the description, select a suitable category from the provided set of categories, calculate the correct total amount and extract the currency used. These values must be inserted into the specified JSON format. 
                    If no currency is stated, set it as SGD. Do not perform any currency conversion.
                    If no value is provided omit the entire json
                    
                    Category: Shopping, Groceries, Subscriptions, Loans, Housing, Transport, Dining, Utilities, Transfers, Taxes, Utilities, Healthcare, Insurance, Entertainment, Miscellaneous
                    Description:  {description}
                    JSON format: 
                    [
                        {{
                            name: <some_value>,
                            category: <some_value>,
                            amount: <some_value to 2 decimal >,
                            currency: <some_value>
                        }}
                    ]
                """,
            },
        ],
    }

    # Send the request and receive the response
    response = requests.post(url, headers=headers, data=json.dumps(payload))

    # Parse the response content to a Python dict
    response_json = response.json()

    # Extract the desired output from the response
    try:
        return json.loads(response_json["choices"][0]["message"]["content"])
    except KeyError:
        # In case of an error or unexpected response structure
        return "An error occurred while processing the request."


def get_exchange_rate(from_currency):
    url = f"https://open.er-api.com/v6/latest/{from_currency}"
    response = requests.get(url)
    data = response.json()

    return data["rates"]["SGD"]


def convert_to_sgd(amount, from_currency):
    if from_currency != "SGD":
        exchange_rate = get_exchange_rate(from_currency)
        return amount * exchange_rate
    return amount


def get_cookie(event, cookie_name):
    try:
        cookies = event["headers"]["Cookie"]
        cookie_arr = cookies.split(";")

        print(cookies)

        for cookie in cookie_arr:
            print(cookie)
            if cookie.split("=")[0] == cookie_name:
                if cookie.split("=")[1]:
                    return cookie.split("=")[1]
                else:
                    return False
        return False
    except:
        return False
